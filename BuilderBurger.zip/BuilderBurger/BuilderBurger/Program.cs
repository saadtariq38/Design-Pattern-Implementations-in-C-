﻿public interface IItem
{
    public string GetName();
    public IPackaging GetPackaging();
    public float GetPrice();
}

public class MealBuilder {  //Any drink can be taken in a packaging off your choice from either bottle or can
    public Meal prepareVegMeal (){
      Meal meal = new Meal();
      meal.AddItem(new VegBurger());
      meal.AddItem(new Coke(new Can()));    //Coke in can
      meal.AddItem(new MasalaFries());
      return meal;
   }   

   public Meal prepareNonVegMeal (){
      Meal meal = new Meal();
      meal.AddItem(new ChickenBurger());
      meal.AddItem(new Dew(new Bottle()));  //Dew in Bottle
      meal.AddItem(new MayoFries());
      return meal;
   }

   public Meal prepareSaadTSpecialCans (){
      Meal meal = new Meal();
      meal.AddItem(new ChickenBurger());
      meal.AddItem(new VegBurger());
      meal.AddItem(new Dew(new Can())); 
      meal.AddItem(new Coke(new Can()));
      meal.AddItem(new MayoFries());
      meal.AddItem(new MasalaFries());
      return meal;
   }

   public Meal prepareSaadTSpecialBottles (){
      Meal meal = new Meal();
      meal.AddItem(new ChickenBurger());
      meal.AddItem(new VegBurger());
      meal.AddItem(new Dew(new Bottle())); 
      meal.AddItem(new Coke(new Bottle()));
      meal.AddItem(new MayoFries());
      meal.AddItem(new MasalaFries());
      return meal;
   }
}
public class Meal
{
    private List<IItem> items = new List<IItem>();
    public void AddItem(IItem item)
    {
        items.Add(item);
    }

    public float GetCost()
    {
        float total = 0;
        foreach (IItem item in items)
        {
            total += item.GetPrice();
        }
        return total;
    }

    public void ShowItems()
    {

        foreach (IItem item in items)
        {
            Console.WriteLine("Name: " + item.GetName());
            Console.WriteLine("Price: " + item.GetPrice());
            Console.WriteLine("Packaging: " + item.GetPackaging().GetPackaging());
            Console.WriteLine("x--------------------x------------------------x");
        }
    }
}

public interface IPackaging {
    public string GetPackaging();
}

public class Wrapper : IPackaging {
    public string GetPackaging() {
        return "Wrapper";
    }
}

public class Bottle : IPackaging {
    public string GetPackaging() {
        return "Bottle";
    }
}

public class Can : IPackaging {
    public string GetPackaging() {
        return "Can";
    }
}

public class Box : IPackaging { //Pacakging for Fries item
    public string GetPackaging() {
        return "Box";
    }
}
    
public abstract class Fries : IItem {
    public IPackaging GetPackaging () {
        return new Box();
    }

    public abstract string GetName();
    public abstract float GetPrice();
}

public abstract class Burger : IItem {
    public IPackaging GetPackaging() {
        return new Wrapper();
    }
    public abstract string GetName();
    public abstract float GetPrice();

}

public abstract class ColdDrink : IItem{

    private IPackaging packaging;
    public ColdDrink(IPackaging packaging) {
        this.packaging = packaging;
    }
    public IPackaging GetPackaging() {
        return packaging;
    }
    public abstract string GetName();
    public abstract float GetPrice();
}

public class ChickenBurger : Burger {
    public override string GetName(){
        return "Chicken Burger";
    }

    public override float GetPrice() {
        return 25.5f;
    }
}

public class VegBurger : Burger {
    public override string GetName(){
        return "Veg Burger";
    }

    public override float GetPrice() {
        return 20.5f;
    }
}

public class Coke : ColdDrink {

    IPackaging package;
     public Coke(IPackaging packaging) : base(packaging)
    {
        package = packaging;
    }
    public override string GetName()
    {
        return "Coke";
    }

    public override float GetPrice()
    {
        if(package.GetPackaging() == "Can") {
            return 2.5f;
        } else if (package.GetPackaging() == "Bottle") {
            return 2f;
        } else {
            throw new InvalidOperationException();
        }
        
    }
}

public class Dew : ColdDrink {

    IPackaging package;
    public Dew(IPackaging packaging) : base(packaging)
    {
        package = packaging;
    }
    public override string GetName()
    {
        return "Mountain Dew";
    }

    public override float GetPrice()
    {
        if(package.GetPackaging() == "Can") {
            return 2.5f;
        } else if (package.GetPackaging() == "Bottle") {
            return 2f;
        } else {
            throw new InvalidOperationException();
        }
        
    }
}

public class MayoFries : Fries {
    public override string GetName()
    {
        return "Mayo Fries";
    }

    public override float GetPrice()
    {
        return 16f;
    }
}

public class MasalaFries : Fries {
    public override string GetName()
    {
        return "Masala Fries";
    }

    public override float GetPrice()
    {
        return 14f;
    }
}


class Program {
    static void Main() {
        MealBuilder builder = new MealBuilder();
        Meal veg = builder.prepareVegMeal();
        Meal nonVeg = builder.prepareNonVegMeal();

        //same meals with different cold drink packaging. Total price is different. Cans cost more.
        Meal saadTSpecialCans = builder.prepareSaadTSpecialCans();
        Meal saadTSpecialBottles = builder.prepareSaadTSpecialBottles();

        veg.ShowItems();
        Console.WriteLine("Total price: " + veg.GetCost());
        Console.WriteLine("-----------------x--------------------");
        nonVeg.ShowItems();
        Console.WriteLine("Total price: " + nonVeg.GetCost());
        Console.WriteLine("-----------------x--------------------");
        saadTSpecialCans.ShowItems();
        Console.WriteLine("Total price: " + saadTSpecialCans.GetCost());
        Console.WriteLine("-----------------x--------------------");
        saadTSpecialBottles.ShowItems();
        Console.WriteLine("Total price: " + saadTSpecialBottles.GetCost());


    }
}

