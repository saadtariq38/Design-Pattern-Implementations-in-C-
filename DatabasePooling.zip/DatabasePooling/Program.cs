﻿
using dotenv.net;

public static class DatabasePooling
{
    private static int conns = 0;
    private static List<Connection> connectionPool = new List<Connection>();
    private readonly static int maxConnections = GetMaxConnectionsFromEnvironment();

    private static int RRIndex = 0;

    private static int GetMaxConnectionsFromEnvironment()
    {
        string maxConnectionsEnv = Environment.GetEnvironmentVariable("MAX_CONNECTIONS");
        if (int.TryParse(maxConnectionsEnv, out int result) && result > 0)
        {
            return result;
        }
        return 10;
    }
    public static Connection GetInstance()
    {
        if (conns < maxConnections)
        {
            conns += 1;
            Connection newConnection = new Connection(conns);
            connectionPool.Add(newConnection);
            Console.WriteLine("New connection created");
            return newConnection;
        }
        else
        {
            //Round Robin implementation
           int pos;

            // Wrap around to 0 if index reaches the maximum value
            if (RRIndex == int.MaxValue)
            {
                RRIndex = 0;
            }

            pos = RRIndex % maxConnections;
            RRIndex++;
            Console.WriteLine("Connection with id " + (pos+1) + " recieved");
            return connectionPool[pos];
        }
    }
    public class Connection
    {
        private int Id;

        public Connection(int id)
        {
            Id = id;
        }

        public int GetId()
        {
            return Id;
        }
    }

}

class Program
{
    static void Main()
        {
            DotEnv.Load();

            for (int i = 0; i < 25; i++)
            {
                DatabasePooling.Connection connection = DatabasePooling.GetInstance();
                Console.WriteLine("Connection ID: " + connection.GetId());
            }
        }

}