﻿
public abstract class Subject {
    public abstract void AddObserver(Observer observer);
    public abstract void RemoveObserver(Observer observer);
    public abstract void Notify();
}

public class ClockTimer : Subject {

    //Global Time to be passed on to observers
    TimeOnly Time;
    //List of all subscribers
    List<Observer> SubscriberList = new List<Observer>();

    public ClockTimer(TimeOnly Time) {
        this.Time = Time;
    }

    public void ChangeTime(TimeOnly time) { //Used to update time and send the new value to all subscribers 
        Time = time;
        Notify();
    }

    public override void AddObserver(Observer observer) {
        try
        {
            SubscriberList.Add(observer);
        }
        catch (System.Exception)
        {
            throw;
        }

    }
    public override void RemoveObserver(Observer observer) {
        try
        {
            SubscriberList.Remove(observer);
        }
        catch (System.Exception)
        {
            throw;
        }
    }
    public override void Notify() {     //Sends the time to all subscribed observers
        foreach (Observer observer in SubscriberList) {
           observer.Update(Time);
        }
    }

}
public abstract class Observer {
    public abstract void Update(TimeOnly time);
}

public class AnalogClock : Observer {
    private TimeOnly time;
    public override void Update(TimeOnly time) {   //Updates time locally and displays in the correct format using Draw()
        this.time = time;
        Draw();
    }

    public void Draw() {
        Console.WriteLine($"Analog Time is {time.Hour}:{time.Minute}:{time.Second}");
    }   
    public void Subscribe(Subject subject) {       //Adds itself to the observer list for a particular subject
        try
        {
            subject.AddObserver(this);
            Console.WriteLine("Analog clock observer added");
        }
        catch (System.Exception)
        {
            throw;
        }
    }
    public void Unsubscribe(Subject subject) {  //Removes itself from the observer list for a particular subject
        try
        {
            subject.RemoveObserver(this);
            Console.WriteLine("Analog clock observer removed");
        }
        catch (System.Exception)
        {
            throw;
        }
    }
}

public class DigitalClock : Observer {
    private TimeOnly time;
    public override void Update(TimeOnly time) {    //Updates time locally and displays in the correct format using Draw()
        this.time = time;
        Draw();
    }

    public void Draw() {
        Console.WriteLine($"Digital Clock: {time:hh\\:mm\\:ss}");
    }
    public void Subscribe(Subject subject) {    //Adds itself to the observer list for a particular subject
        try
        {
            subject.AddObserver(this);
            Console.WriteLine("Digital clock observer added");  
        }
        catch (System.Exception)
        {
            
            throw;
        }
    }
    public void Unsubscribe(Subject subject) {
        try
        {
            subject.RemoveObserver(this);
            Console.WriteLine("Digital clock observer removed"); 
        }
        catch (System.Exception)
        {  
            throw;
        }
    }
}
public class Program {
    public static void Main() {
        ClockTimer Clock = new ClockTimer(TimeOnly.FromDateTime(DateTime.Now));
        DigitalClock DigitalClock = new DigitalClock();
        AnalogClock AnalogClock = new AnalogClock();

        DigitalClock.Subscribe(Clock);
        AnalogClock.Subscribe(Clock);

        //Displays both clock times since both are subscribed
        Clock.ChangeTime(TimeOnly.FromDateTime(DateTime.Now));

        DigitalClock.Unsubscribe(Clock);

        //Only displays Analog clock time becasue Digital unsubscribed
        Clock.ChangeTime(TimeOnly.FromDateTime(DateTime.Now));


    }
}


