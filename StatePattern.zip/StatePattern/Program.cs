﻿
public class Client {
    public static void Main() {
        Context context = new Context(new Entry());
        context.DoAction();
    }
}

// The program makes use of data states in the context class as shown with the New User functionality.
// Each decision is a seperate state and is naviagted through user inputs
// The program ends and needs to be run again if you reach the checkout state
// The program will tell you through console your user journey


//-------------------------------------Muhammad Saad Tariq - 22947----------------------------------------------------------

public class Context {
    private IState state;    //Global state variable
    public bool IsNewUser {get; set;}   //For deciding whether to login or register a user
    public Context (IState InitState) {
        state = InitState;
        IsNewUser = true;   //sets new context of user as true
    }

    public IState GetState() {   //Getter for state
        if(state == null) {
            throw new InvalidOperationException();
        }

        return state;
    }

    public void UpdateState(IState state) {  //Setter for state
        this.state = state;
    }

    public void DoAction() {    //Fucntion to call the present states operation
        try
        {
            state.Operation(this);
        }
        catch (Exception)
        { 
            throw;
        }

    }
}

public interface IState {
    public void Operation(Context context);    //Each state will perform one operation according to Single Responsibility Principle
}

public class Entry : IState{    //Initial State for entry point to the app
    public void Operation(Context context) {
        try
        {
            if(context.IsNewUser) {
            Console.WriteLine("New user, sending to register page");
            context.UpdateState(new RegisterState());
            context.DoAction();
        } else {
            Console.WriteLine("Old user, sending to login page");
            context.UpdateState(new LoginState());
            context.DoAction();
        }
        }
        catch (Exception)
        {
            throw;
        }
    } 
}

public class RegisterState : IState {
    public void Operation(Context context) {
        try
        {
            context.IsNewUser = false;
            Console.WriteLine("User Registered, sending to login page");
            context.UpdateState(new LoginState());
            context.DoAction();
        }
        catch (Exception)
        {
            throw;
        }
        
    }
}

public class LoginState : IState {
    public void Operation(Context context) {
        try
        {
            Console.WriteLine("user logged in");
            context.UpdateState(new SearchOrViewCartState());
            context.DoAction();
        }
        catch (Exception)
        {
            throw;
        }
    }
}

public class SearchOrViewCartState : IState {
    public void Operation(Context context)
    {
        try
        {
            
            bool goToSearch = GetUserInput(); //Gets user input on where they want to proceed

            // Updates state accordingly
            if (goToSearch)
            {
                context.UpdateState(new SearchItemState());
                context.DoAction();
            }
            else
            {
                context.UpdateState(new CartState());
                context.DoAction();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    // Replace this method with your actual logic to get user input or any other condition
    private bool GetUserInput()
    {
        Console.WriteLine("Do you want to go to the search state? (y/n)");
        string userInput = Console.ReadLine();
        if(userInput == null || (userInput != "y" && userInput != "n" && userInput != "N" && userInput != "Y")) {
            Console.WriteLine("Invalid Input. Try again");
            GetUserInput();
        }
        return userInput.ToLower() == "y";
    }
}

public class CartState : IState
{
    public void Operation(Context context)
    {
        try
        {
            Console.WriteLine("present in viewing cart state");
            //User selects either C, R, S to go to selected state
            string userChoice = GetUserChoice(); 

            // Transition to the appropriate state based on the user's choice
            switch (userChoice.ToLower())
            {
                case "c":
                    context.UpdateState(new CheckoutState());
                    context.DoAction();
                    break;
                case "r":
                    context.UpdateState(new RemoveItemState());
                    context.DoAction();
                    break;
                case "s":
                    context.UpdateState(new SearchItemState());
                    context.DoAction();
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please choose 'Checkout', 'RemoveItem', or 'Search'.");
                    break;
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    // Replace this method with your actual logic to determine whether to go to the checkout state
    private string GetUserChoice()
    {
        Console.WriteLine("Which State do you want to go to? Checkout (c) / Search (s) / Remove Item (r)");
        string userInput = Console.ReadLine();
        if(userInput == null || (userInput != "c" && userInput != "r" && userInput != "s" && userInput != "C"  && userInput != "R" && userInput != "S")) {
            Console.WriteLine("Invalid Input. Try again");
            GetUserChoice();
        }
        return userInput.ToLower();
    }
}

public class CheckoutState : IState {
    public void Operation(Context context) {
        Console.WriteLine("Checked out");
        context.UpdateState(new Entry());
        Console.WriteLine("End of program, pls run again thankyou");
    }
}

public class RemoveItemState : IState {
    public void Operation(Context context) {
        Console.WriteLine("Removing State selected");
        context.UpdateState(new SearchOrViewCartState());
        context.DoAction();
    }
}

public class SearchItemState : IState {
    public void Operation(Context context) {
        try
        {
            Console.WriteLine("Searching Item");
            bool FoundItem = FindItem(); //For now the search logic is user directly telling if they found item or not

            // Updates state accordingly
            if (FoundItem)
            {
                context.UpdateState(new ViewItemState());
                context.DoAction();
            }
            else
            {
                context.UpdateState(new SearchOrViewCartState());
                context.DoAction();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    public bool FindItem() {
        Console.WriteLine("Did you find your desired item (y/n)");
        string userInput = Console.ReadLine();
        if(userInput == null || (userInput != "y" && userInput != "n" && userInput != "N" && userInput != "Y")) {
            Console.WriteLine("Invalid Input. Try again");
            FindItem();
        }
        return userInput.ToLower() == "y";
    }
}

public class ViewItemState : IState {
    public void Operation(Context context) {
         try
        {
            Console.WriteLine("viewing item");
            bool addToCart = LikedItem(); //For now the search logic is user directly telling if they found item or not

            // Updates state accordingly
            if (addToCart)
            {
                context.UpdateState(new AddToCartState());
                context.DoAction();
            }
            else
            {
                context.UpdateState(new SearchItemState());
                context.DoAction();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    public bool LikedItem() {
        Console.WriteLine("Did you want to add your desired item to the cart (y/n)");
        string userInput = Console.ReadLine();
        if(userInput == null || (userInput != "y" && userInput != "n" && userInput != "N" && userInput != "Y")) {
            Console.WriteLine("Invalid Input. Try again");
            LikedItem();
        }
        return userInput.ToLower() == "y";
    }
}

public class AddToCartState :IState {
    public void Operation(Context context) {
        Console.WriteLine("Item added to cart");
        context.UpdateState(new ViewCartOrSearchState());
        context.DoAction();
    }
}

public class ViewCartOrSearchState : IState {
    public void Operation(Context context) {
        try
        {
            bool viewCart = ViewCart(); //For now the search logic is user directly telling if they found item or not

            // Updates state accordingly
            if (viewCart)
            {
                context.UpdateState(new CartState());
                context.DoAction();
            }
            else
            {
                context.UpdateState(new SearchItemState());
                context.DoAction();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    public bool ViewCart() {
        Console.WriteLine("Do you want to view your cart (y/n)");
        string userInput = Console.ReadLine();
        if(userInput == null || (userInput != "y" && userInput != "n" && userInput != "N" && userInput != "Y")) {
            Console.WriteLine("Invalid Input. Try again");
            ViewCart();
        }
        return userInput.ToLower() == "y";
    }
}

